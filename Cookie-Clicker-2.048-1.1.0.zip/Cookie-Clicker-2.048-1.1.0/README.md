# Cookie-Clicker-2.048

I got the new update source code!
Play it here! --> https://sushi8756.github.io/Cookie-Clicker-2.048/
